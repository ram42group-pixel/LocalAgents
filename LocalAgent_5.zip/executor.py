# -*- coding: utf-8 -*-
#executor.py — 実行レイヤー（system役の行動JSONを実際に実行する）
"""
agent_loop の execute_action がここを呼ぶ。
行動JSON（json_checker.handle_task を通ったもの）を受け取り、実際に実行して
結果文字列を返す。安全のため、副作用のある操作は必ずユーザー承認を挟む。

  result = run_action(action)            # 対話承認つき
  result = run_action(action, approver=auto_yes)  # テスト用に承認を差し替え可

対応:
  command : シェルコマンド実行（承認必須・タイムアウトつき）
  file    : read / write / append / delete（write/append/delete は承認必須）
  code    : python等のコードを一時ファイルに保存して実行（承認必須）
  assist  : AIからの質問をユーザーに尋ね、回答を結果として返す
"""
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import shell
import installs
import ssh_session
import servers

WORKSPACE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "workspace")

def _resolve(path: str) -> str:
    """file操作のpathを必ず workspace/ 配下に解決する（../ や絶対パス脱出を防ぐ）。"""
    os.makedirs(WORKSPACE, exist_ok=True)
    p = os.path.abspath(os.path.join(WORKSPACE, os.path.basename(path)
                                     if os.path.isabs(path) else path))
    if not p.startswith(WORKSPACE):
        raise ValueError("workspace外への操作は禁止")
    return p

COMMAND_TIMEOUT = 600    # 秒（インストール等を許容して長め）
CODE_TIMEOUT = 600
OUTPUT_LIMIT = 4000
# 隔離環境なら True で全操作を無確認実行（環境変数 AGENT_AUTO_APPROVE=1 でも可）
AUTO_APPROVE = os.environ.get("AGENT_AUTO_APPROVE") == "1"      # 結果文字列の上限（長大な出力で記憶を溢れさせない）

# code の language → 実行コマンド
_RUNNERS = {
    "python": [sys.executable],
    "py": [sys.executable],
    "bash": ["bash"],
    "sh": ["sh"],
}


def _truncate(text: str) -> str:
    text = text or ""
    if len(text) > OUTPUT_LIMIT:
        return text[:OUTPUT_LIMIT] + f"\n…(出力を{OUTPUT_LIMIT}字で切り詰め)"
    return text


def _ask_approval(prompt: str) -> bool:
    """対話でユーザー承認を取る。AUTO_APPROVE時は無確認で許可。"""
    if AUTO_APPROVE:
        return True
    try:
        ans = input(f"{prompt} 実行しますか? [y/N] > ").strip().lower()
    except EOFError:
        return False
    return ans == "y"


def auto_yes(_prompt: str) -> bool:
    """テスト用：常に承認。"""
    return True


def auto_no(_prompt: str) -> bool:
    """テスト用：常に拒否。"""
    return False


# ----------------------------------------------------------------------- #
# 各 type の実行
# ----------------------------------------------------------------------- #
def _pull_remote_outputs(cmd: str) -> str:
    """Kali上のコマンドが出力ファイルを作った場合、その中身をローカルworkspaceに控える。
    対象: リダイレクト( > file ), nmap -oN/-oA/-oX/-oG, tee file 等。"""
    import re
    paths = []
    # > file / >> file
    for m in re.finditer(r">>?\s*([^\s;|&>]+)", cmd):
        paths.append(m.group(1))
    # nmap -oN/-oX/-oG/-oA <base> , -o <file>
    for m in re.finditer(r"-o[NXGA]?\s+([^\s;|&]+)", cmd):
        paths.append(m.group(1))
    # tee [-a] file
    for m in re.finditer(r"\btee\s+(?:-a\s+)?([^\s;|&]+)", cmd):
        paths.append(m.group(1))
    if not paths:
        return ""
    os.makedirs(WORKSPACE, exist_ok=True)
    saved = []
    for rpath in dict.fromkeys(paths):           # 重複除去・順序維持
        rpath = rpath.strip("'\"")
        if not rpath or rpath.startswith("/dev/") or rpath == "-":
            continue
        content = ssh_session.run(f"cat {rpath} 2>/dev/null", timeout=60)
        if content.startswith("エラー:") or not content.strip():
            continue
        local = os.path.join(WORKSPACE, "kali_" + os.path.basename(rpath))
        try:
            with open(local, "w", encoding="utf-8", errors="replace") as f:
                f.write(content)
            saved.append(os.path.basename(local))
        except OSError:
            pass
    if saved:
        return f"[Kaliの出力をローカルに保存: {', '.join(saved)}（workspace内）]\n"
    return ""


def _run_command(action: dict, approver) -> str:
    cmd = action.get("command", "")
    if not cmd:
        return "エラー: commandが空"
    # SSH接続中ならリモート(Kali等)で実行する
    if ssh_session.is_connected():
        if not approver(f"SSH実行({ssh_session.status()['host']}): {cmd}"):
            return "ユーザーが実行を拒否しました"
        # 対話型コマンド用の入力（LLMが "input" に指定。例: yes応答やパスワード）
        input_text = action.get("input")
        if input_text and not input_text.endswith("\n"):
            input_text += "\n"
        out = ssh_session.run(cmd, timeout=COMMAND_TIMEOUT, input_text=input_text)
        ok = not out.startswith("エラー:")
        rec = installs.record(cmd, ok, where=ssh_session.status()["host"])
        note = ""
        if rec:
            note = f"[記録: {rec['manager']} {', '.join(rec['packages'])} を{'導入' if ok else '導入失敗'}@{rec['where']}]\n"
        # Kali側で出力ファイルが作られた場合、ローカルにも控えを取り戻す（手元に残す）
        pulled = _pull_remote_outputs(cmd)
        if pulled:
            note += pulled
        return note + (_truncate(out) or "(出力なし)")
    if not approver(f"コマンド({shell.shell_name()}): {cmd}"):
        return "ユーザーが実行を拒否しました"
    os.makedirs(WORKSPACE, exist_ok=True)   # 実行カレントを用意
    # 常駐コマンド（uvicorn --reload 等）は待たずにバックグラウンド起動（無限ループ防止）
    if servers.is_long_running(cmd):
        return servers.start_background(cmd, shell.shell_prefix(), WORKSPACE)
    try:
        # OSに応じたシェル（Windows=PowerShell / Linux=bash 等）で実行
        proc = subprocess.run(
            shell.shell_prefix() + [cmd], capture_output=True, text=True,
            timeout=COMMAND_TIMEOUT, cwd=WORKSPACE,
        )
    except subprocess.TimeoutExpired:
        return f"エラー: タイムアウト（{COMMAND_TIMEOUT}秒）"
    ok = proc.returncode == 0
    rec = installs.record(cmd, ok)          # pip/apt/npm等のインストールを記録
    note = ""
    if rec:
        note = f"[記録: {rec['manager']} {', '.join(rec['packages'])} を{'導入' if ok else '導入失敗'}]\n"
    if ok:
        return note + (_truncate(proc.stdout) or "(出力なし・成功)")
    return note + _truncate(f"エラー(code={proc.returncode}): {proc.stderr or proc.stdout}")


def _run_ssh_connect(action: dict, approver) -> str:
    host = action.get("host"); user = action.get("user")
    if not host or not user:
        return "エラー: host と user が必要です"
    if not approver(f"SSH接続: {user}@{host}"):
        return "ユーザーが接続を拒否しました"
    return ssh_session.connect(host, user, int(action.get("port", 22)),
                               action.get("password"), action.get("key_path"))


def _run_server_stop(action: dict, approver) -> str:
    pid = action.get("pid")
    if pid is None:
        return servers.stop_all()
    return servers.stop(int(pid))


def _run_server_list(action: dict, approver) -> str:
    import json as _j
    return _j.dumps(servers.list_servers(), ensure_ascii=False)


def _run_tool(action: dict, approver) -> str:
    import tools.registry as tr
    name = action.get("name", "")
    args = action.get("args", {}) or {}
    if not approver(f"ツール実行: {name}({args})"):
        return "ユーザーが実行を拒否しました"
    return _truncate(tr.run_tool(name, args))


def _run_ssh_disconnect(action: dict, approver) -> str:
    return ssh_session.disconnect()


def _run_file(action: dict, approver) -> str:
    act = action.get("action", "") or "write"   # 省略時は write（プロンプト契約に整合）
    path = action.get("path", "")
    if not path:
        return "エラー: pathが空"
    try:
        path = _resolve(path)   # ★生成物は必ず workspace/ へ
    except ValueError as ex:
        return f"エラー: {ex}"

    if act == "read":
        try:
            with open(path, "r", encoding="utf-8") as f:
                return _truncate(f.read())
        except OSError as e:
            return f"エラー: 読み込み失敗 {e}"

    if act in ("write", "append"):
        if not approver(f"ファイル{act}: {path}"):
            return "ユーザーが操作を拒否しました"
        mode = "w" if act == "write" else "a"
        try:
            with open(path, mode, encoding="utf-8") as f:
                f.write(action.get("content", ""))
            return f"OK: {path} に{act}しました"
        except OSError as e:
            return f"エラー: 書き込み失敗 {e}"

    if act == "delete":
        if not approver(f"ファイル削除: {path}"):
            return "ユーザーが操作を拒否しました"
        try:
            os.remove(path)
            return f"OK: {path} を削除しました"
        except OSError as e:
            return f"エラー: 削除失敗 {e}"

    return f"エラー: 未知のfile action: {act}"


def _run_code(action: dict, approver) -> str:
    lang = (action.get("language") or "python").lower()
    code = action.get("code", "")
    if not code:
        return "エラー: codeが空"
    runner, _suffix = shell.code_runner(lang)
    if runner is None:
        return f"エラー: この環境では未対応の言語: {lang}（OS={shell.SYSTEM}）"

    # path があれば「成果物としてworkspaceに保存」する（残らないと意味がないコード生成用）
    path = action.get("path")
    saved_note = ""
    if path:
        try:
            saved = _resolve(path)
        except ValueError as ex:
            return f"エラー: {ex}"
        if not approver(f"コードを保存: {path}"):
            return "ユーザーが保存を拒否しました"
        try:
            with open(saved, "w", encoding="utf-8") as f:
                f.write(code)
            saved_note = f"OK: {saved} に保存しました"
        except OSError as ex:
            return f"エラー: 保存失敗 {ex}"

    # run=False（既定はpathがあれば保存のみ／なければ実行）。明示的に実行可否を選べる
    run = action.get("run", path is None)
    if not run:
        return saved_note or "OK: コードを生成しました（実行はしていません）"

    if not approver(f"{lang}コードを実行:\n{code[:200]}"):
        return (saved_note + "\n" if saved_note else "") + "ユーザーが実行を拒否しました"

    suffix = _suffix
    tmp = tempfile.NamedTemporaryFile("w", suffix=suffix, delete=False, encoding="utf-8")
    try:
        tmp.write(code)
        tmp.close()
        proc = subprocess.run(
            runner + [tmp.name], capture_output=True, text=True, timeout=CODE_TIMEOUT,
        )
    except subprocess.TimeoutExpired:
        return f"エラー: タイムアウト（{CODE_TIMEOUT}秒）"
    finally:
        try:
            os.remove(tmp.name)
        except OSError:
            pass

    head = (saved_note + "\n") if saved_note else ""
    if proc.returncode == 0:
        return head + (_truncate(proc.stdout) or "(出力なし・成功)")
    return head + _truncate(f"エラー(code={proc.returncode}): {proc.stderr or proc.stdout}")


def _run_assist(action: dict, approver) -> str:
    msg = action.get("message", "（質問なし）")
    try:
        return input(f"AIからの確認: {msg} > ").strip() or "(回答なし)"
    except EOFError:
        return "(回答なし)"


def _run_web_search(action: dict, approver) -> str:
    """web_search型: engine で検索し、結果テキストを返す（承認不要・副作用なし）。"""
    query = action.get("query", "")
    if not query:
        return "エラー: queryが空"
    try:
        from engine import search
    except Exception as e:                       # noqa: BLE001
        return f"エラー: engine読込失敗 {e}"
    eng = action.get("engine")                   # 任意指定。無ければ既定＋フォールバック
    deep = action.get("deep", True)              # 既定で深掘り（LLMが重要リンクを選び実ページ取得）
    if deep:
        from engine import deep_search
        return _truncate(deep_search(query, limit=5, engine=eng))
    resp = search(query, limit=5, engine=eng)
    return _truncate(resp.to_text())


_DISPATCH = {
    "command": _run_command,
    "file": _run_file,
    "code": _run_code,
    "assist": _run_assist,
    "web_search": _run_web_search,
    "ssh_connect": _run_ssh_connect,
    "ssh_disconnect": _run_ssh_disconnect,
    "tool": _run_tool,
    "server_stop": _run_server_stop,
    "server_list": _run_server_list,
}


def run_action(action: dict, approver=_ask_approval, dry_run: bool = False) -> str:
    """
    行動JSONを実行して結果文字列を返す。
    approver(prompt)->bool で承認方法を差し替え可。dry_run=True なら実行せず計画のみ返す。
    """
    t = action.get("type")
    if dry_run:
        detail = (action.get("command") or action.get("path")
                  or action.get("language") or action.get("message") or "")
        # ドライランでも「計画は妥当＝成功とみなす」結果を返す。
        # （未実行を強調すると judge が永久に未完了と判断しループするため）
        return f"OK（ドライラン・シミュレート成功）{t}: {detail}"
    handler = _DISPATCH.get(t)
    if handler is None:
        return f"エラー: 未知のtype: {t}"
    return handler(action, approver)


if __name__ == "__main__":
    # 自動承認でひと通り動作確認（安全な範囲のみ）
    print(run_action({"type": "command", "command": "echo hello"}, approver=auto_yes))
    print(run_action({"type": "command", "command": "echo secret"}, approver=auto_no))
    print(run_action({"type": "file", "action": "write", "path": "/tmp/_ex_test.txt",
                      "content": "data"}, approver=auto_yes))
    print(run_action({"type": "file", "action": "read", "path": "/tmp/_ex_test.txt"}))
    print(run_action({"type": "code", "language": "python",
                      "code": "print(2+3)"}, approver=auto_yes))
    print(run_action({"type": "unknown"}))
