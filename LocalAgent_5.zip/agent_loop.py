# -*- coding: utf-8 -*-
#agent_loop.py — 本体ループ（goal分解→目的ごとに計画→実行→要約→記憶）
"""
LLMアクセスは providers.ask(role, messages) に統一。
進行状況は emit(event:dict) で外へ流す（CLIはコンソール表示、Webはブラウザへ）。
モデル差し替えは providers/registry.py の ROLE_ROUTES（またはWeb UI）。
"""
import sys as _sys
try:  # WindowsのコンソールをUTF-8に揃える（文字化け防止）
    _sys.stdout.reconfigure(encoding="utf-8")
    _sys.stdin.reconfigure(encoding="utf-8")
except Exception:
    pass

import sys

import fast_connect
import json_checker as jc
import executor
import shell
import ssh_session
import installs
import session
import modes
import stats
import budget
import kali_tools
from dedup import Deduplicator, explain_duplicate, OutputTracker, explain_bad_json
from providers import ask
from memory import LongTermMemory, ShortTermMemory
from memory.short_term import is_failure_result

RETRIES = 3
MAX_TURNS_PER_OBJECTIVE = 12

# 実行時フック（run_agent が設定）。emit=進行イベント, approver/dry=実行制御
_HOOK = {"emit": None, "approver": None, "dry": False}
_LTM_REF = {"ltm": None}   # plan_next_action から知識グラフ参照用
_ROUTING = {"on": True}    # 動的ルーティング（能力ベクトルでモデル選択）のON/OFF
_USED_SKILLS = {"ids": set()}  # 今の目的で planner に提示されたスキルID（成否を後で記録）
# 実行中の介入キュー: ユーザーが軌道修正のメッセージを差し込める。
# 各ターンの冒頭で drain され、次のプランに feedback として注入される。
import threading as _threading
_INTERVENTIONS = {"queue": [], "lock": _threading.Lock(), "stop": False}


def push_intervention(text: str) -> None:
    """実行中のエージェントへ介入メッセージを送る（UI/APIから呼ぶ）。
    次のターンの冒頭で取り出され、プランへの指示として反映される。"""
    if not text:
        return
    with _INTERVENTIONS["lock"]:
        _INTERVENTIONS["queue"].append(str(text))


def request_stop() -> None:
    """実行中のエージェントを次の安全な区切りで停止させる。"""
    with _INTERVENTIONS["lock"]:
        _INTERVENTIONS["stop"] = True


def _drain_interventions() -> str:
    """溜まった介入メッセージを取り出して連結（キューは空にする）。"""
    with _INTERVENTIONS["lock"]:
        if not _INTERVENTIONS["queue"]:
            return ""
        msgs = _INTERVENTIONS["queue"][:]
        _INTERVENTIONS["queue"] = []
    return " ".join(msgs)


def _should_stop() -> bool:
    with _INTERVENTIONS["lock"]:
        return _INTERVENTIONS["stop"]


def _reset_interventions() -> None:
    """run開始時にキューと停止フラグを初期化（前回の残りを持ち越さない）。"""
    with _INTERVENTIONS["lock"]:
        _INTERVENTIONS["queue"] = []
        _INTERVENTIONS["stop"] = False
_STEPS = {"plan": []}     # 現在の目的の多段階プラン（手順リスト）
_STM_REF = {"stm": None}  # 現在の短期記憶（ビューア用）


def _console(e: dict) -> None:
    t = e.get("type")
    if t == "goal_done":
        print(f"\n[STEP1] ゴール: {e['goal']}")
        for i, o in enumerate(e["objectives"], 1):
            print(f"   目的{i}: {o}")
        print(f"   タグ: {e['tags']}")
    elif t == "objective_start":
        print(f"\n[STEP2] 目的({e['index']}/{e['total']}): {e['objective']}")
        for m in e.get("related", []):
            print(f"   関連記憶: {m}")
    elif t == "llm_response":
        print(f"   <{e['role']}@{e['model']}> {e['content'][:120]}")
    elif t == "parse_error":
        print(f"   ! 解析失敗({e['attempt']}): {e['error']}")
    elif t == "provider_refusal":
        print(f"   ⛔ LLMが生成を拒否した可能性: {e.get('hint','')}")
    elif t == "local_fallback":
        print(f"   🔁 ローカルLLM(ollama)で再実行しました（{e.get('role')}）")
    elif t == "skill_learned":
        if e.get("name"):
            print(f"   🎓 スキル習得: 「{e['name']}」 {' → '.join(e.get('steps',[]))}")
    elif t == "consolidated":
        print(f"   🧹 記憶整理: 重複{e.get('removed_duplicates',0)}件・教訓{e.get('removed_lessons',0)}件を削除")
    elif t == "debate":
        print(f"   💬 討論{e.get('round')}: {'合意' if e.get('agreed') else '差し戻し → '+e.get('advice','')}")
    elif t == "critic":
        print(f"   🧐 critic: {'OK' if e.get('ok') else '差し戻し → '+e.get('advice','')}")
    elif t == "retry_strategy":
        print(f"   🔄 作戦変更（{e.get('fail_streak')}回目の失敗）")
    elif t == "replan":
        print(f"   🗺 再計画: {' → '.join(e.get('steps',[]))}")
    elif t == "step_plan":
        print(f"   📋 手順プラン: {' → '.join(e.get('steps',[]))}")
    elif t == "reflect":
        ls = e.get('lessons', [])
        print(f"   🎓 自己評価 {e.get('score',0)}点" + (f" / 教訓: {'; '.join(ls)}" if ls else ""))
    elif t == "loop_detected":
        print(f"   🔁 {e.get('message','LOOP DETECTED')}")
    elif t == "duplicate":
        print(f"   ↻ 重複検知 → 実行せず別の手を促す: {e['action'].get('type')}")
    elif t == "action":
        print(f"   手{e['turn']}: {e['action']}")
    elif t == "exec_result":
        print(f"     結果: {e['result'][:200]}")
    elif t == "memory_save":
        print(f"   記憶: {e['summary']}（{'成功' if e['success'] else '未完了'}）")
    elif t == "judge":
        print(f"   判定: {'達成' if e['done'] else '未達成'} — {e.get('reason','')}")
    elif t == "objective_giveup":
        print(f"   ※ 上限{e['turns']}手でも未達成のため打ち切り: {e['objective']}")
    elif t == "resumed":
        if e.get("appended"):
            print(f"   ↩ 前回のゴールに追加要望を足して続行（目的 {len(e['objectives'])}件に拡張）")
        else:
            print(f"   ↩ 前回の続きから再開: 目的 {e['index']+1}/{len(e['objectives'])}（{e['done_count']}件完了済み）")
    elif t == "installs":
        print("\n--- インストール済み ---")
        for it in e["items"]:
            mk = "✓" if it["success"] else "✗"
            print(f"  {mk} [{it['manager']}] {', '.join(it['packages'])}")
    elif t == "final_report":
        print("\n" + "=" * 48)
        print(f"【最終結果】ゴール: {e['goal']}")
        print(f"  達成 {e['done']}/{e['total']} 目的")
        for i, r in enumerate(e["results"], 1):
            mark = "✓" if r["success"] else "×"
            print(f"  {mark} 目的{i}: {r['objective']}")
            print(f"      → {r['summary']}")
        print("=" * 48)
    elif t == "run_done":
        print(f"\n[STEP3] 完了。長期記憶 計{e['ltm_count']}件")
    elif t == "error":
        print(f"   ERROR: {e['msg']}")


def _emit(**e) -> None:
    try:
        stats.observe("flow", e)   # 行動履歴を記録（得意分野/性格/グラフ用）
    except Exception:
        pass
    f = _HOOK["emit"]
    (f or _console)(e)


# ---- 共通: 役割プロンプト＋入力を送り、検証して受け取る ---- #
def ask_role(prompt_role: str, route_role: str, user_text: str, handler,
             task_text: str = ""):
    sp = fast_connect.load_prompt(prompt_role)
    tracker = OutputTracker()          # 同じ崩れた出力の繰り返しを見張る
    last = None
    note = ""                          # 次回に添える噛み砕いた指摘
    # 動的ルーティング: 能力ベクトルから最適モデルを選び、この役割の先頭に一時挿入
    _routed = None
    try:
        if _ROUTING["on"] and task_text:
            import router
            import providers.registry as _reg
            pick = router.route(route_role, task_text)
            if pick:
                prov, mdl = pick
                cur = _reg.ROLE_ROUTES.get(route_role, [])
                if not cur or tuple(cur[0]) != (prov, mdl):
                    _routed = list(cur)        # 退避
                    _reg.ROLE_ROUTES[route_role] = [(prov, mdl)] + \
                        [t for t in cur if tuple(t) != (prov, mdl)]
                    _emit(type="routed", role=route_role,
                          model=f"{prov}/{mdl}", task=task_text[:60])
    except Exception:
        _routed = None
    try:
        return _ask_role_inner(prompt_role, route_role, user_text, handler, sp,
                               tracker, note)
    finally:
        if _routed is not None:
            import providers.registry as _reg
            _reg.ROLE_ROUTES[route_role] = _routed   # 元に戻す（並列汚染防止）


def _ask_role_inner(prompt_role, route_role, user_text, handler, sp,
                    tracker, note):
    last = None
    for attempt in range(RETRIES):
        msgs = [{"role": "system", "content": sp},
                {"role": "user", "content": user_text}]
        if attempt and note:
            msgs.append({"role": "user", "content": note})
        _emit(type="llm_request", role=route_role, prompt_role=prompt_role,
              attempt=attempt + 1,
              messages=[m for m in msgs if m.get("role") != "system"])  # systemは出さない
        res = ask(route_role, msgs)
        _emit(type="llm_response", role=route_role, model=res.model, content=res.content)

        data, err = handler(res)
        if not err:
            _emit(type="parsed", role=route_role, data=data)
            return data

        # クラウドLLMがポリシーで生成を拒否した可能性を検知
        if _looks_like_refusal(res.content):
            _emit(type="provider_refusal", role=route_role,
                  content=res.content[:200],
                  hint=("使用中のLLMがこのリクエストの生成を拒否した可能性があります。"
                        "/experts ページで該当ツールの専門家、または役割のプロバイダを "
                        "ollama（ローカル）に切り替えると、プロバイダのポリシーに依存せず実行できます。"))
            # ローカル(ollama)が使えるなら自動で1回フォールバックを試す
            fb = _retry_local(route_role, msgs, handler)
            if fb is not None:
                _emit(type="local_fallback", role=route_role)
                return fb

        # JSONが崩れた。前回と「まったく同じ崩れ方」かを見て、説明を変える
        repeated = tracker.is_repeat(res.content)
        tracker.remember(res.content)
        last = err
        note = explain_bad_json(err, repeated,
                                jc.contract_hint(prompt_role)
                                or jc.contract_hint(route_role))  # 契約要点も添える
        _emit(type="parse_error", role=route_role, attempt=attempt + 1,
              error=err, repeated=repeated, message=note)

        if not repeated:
            # 違う崩れ方なら、まず安価な修復役に直させてみる
            fixed = repair_json(res.content, err, handler,
                                jc.contract_hint(prompt_role) or jc.contract_hint(route_role))
            if fixed is not None:
                _emit(type="repaired", role=route_role, data=fixed)
                return fixed
        # 同じ崩れ方の繰り返しは修復に回さず、noteを添えて本人に出し直させる
    raise RuntimeError(f"{prompt_role}役の出力が不正: {last}")


# クラウドLLMの典型的な拒否フレーズ（JSONが無く、これらを含むと拒否とみなす）
_REFUSAL_MARKERS = (
    "i cannot", "i can't", "i can not", "i'm unable", "i am unable",
    "i won't", "i will not", "cannot assist", "can't assist", "cannot help",
    "can't help", "unable to assist", "against our", "usage polic", "content polic",
    "not able to provide", "i'm sorry", "i am sorry",
    "お応えできません", "対応できません", "できかねます", "支援できません",
    "お手伝いできません", "ポリシー", "違反",
)


def _looks_like_refusal(text: str) -> bool:
    """LLM応答がポリシー拒否っぽいか（JSONを含まず拒否語を含む）を判定。"""
    if not text:
        return False
    if "{" in text:                      # JSONらしきものがあれば拒否ではない
        return False
    low = text.lower()
    return any(m in low for m in _REFUSAL_MARKERS)


def _retry_local(route_role: str, msgs: list, handler):
    """ローカル(ollama)で1回だけ再試行する。成功すればデータ、無理ならNone。"""
    try:
        import providers.registry as reg
        if "ollama" not in reg.provider_names():
            return None
        models = []
        try:
            models = reg.get_provider("ollama").list_models()
        except Exception:
            pass
        model = models[0] if models else ""
        res = reg.ask_direct("ollama", model, msgs, role=route_role)
        data, err = handler(res)
        return data if not err else None
    except Exception:
        return None


def repair_json(broken: str, err: str, handler, contract: str = ""):
    """壊れた出力をLLMに修復させ、検証に通れば dict を返す。失敗なら None。"""
    _emit(type="fn", fn="repair_json", note="壊れたJSONをLLMで修復中")
    msgs = [
        {"role": "system",
         "content": "あなたはJSON修復器です。入力の壊れたJSONを意味を変えずに正しい"
                    "JSONに直し、JSONのみを出力してください。説明文・コードフェンス禁止。"},
        {"role": "user", "content": (f"エラー: {err}\n"
                                     + (f"正しい形: {contract}\n" if contract else "")
                                     + f"壊れた出力:\n{broken[:2000]}")},
    ]
    try:
        res = ask("judge", msgs)
        data, e2 = handler(res)
        return data if not e2 else None
    except Exception:
        return None


def make_goal(request: str) -> dict:
    _emit(type="fn", fn="make_goal", note="goal役: 要望をゴール/目的/タグに分解")
    return ask_role("goal", "goal", request, jc.handle_goal)


def _additional_objectives(request: str, prev_goal: str, tags: list) -> list:
    """完了済みセッションに対する追加要望を、新しい目的リストに分解する。
    既存ゴールの文脈を踏まえて、続きとして実行すべき目的だけを返す。"""
    _emit(type="fn", fn="additional_objectives", note="goal役: 追加要望を目的に分解")
    try:
        ctx = (f"これまでのゴール: {prev_goal}\n"
               f"そのゴールは既に完了している。ユーザーから次の追加要望が来た:\n{request}\n"
               "この追加要望を達成するための目的だけを分解して返すこと。")
        data = ask_role("goal", "goal", ctx, jc.handle_goal)
        objs = data.get("objectives", [])
        return [o for o in objs if isinstance(o, str) and o.strip()]
    except Exception:
        return []


def plan_next_action(stm: ShortTermMemory, related: list[str],
                     feedback: str = "") -> dict:
    _emit(type="fn", fn="plan_next_action", note="system役: 次の1手を計画")
    env_line = shell.describe()
    ssh_line = ssh_session.describe()
    if ssh_line:
        env_line = ssh_line + " ／ コマンドはこの接続先で実行される"
    inst = installs.installed_list()
    inst_line = ""
    if inst:
        names = ", ".join(f"{i['manager']}:{i['package']}" for i in inst[:20])
        inst_line = f"\n【導入済み】{names}（これらは再インストール不要。再度installしない）"
    # 知識グラフから関連知識を引いてLLMに渡す（Wikipedia的に関連をたどる）
    know_line = ""
    lesson_line = ""
    sem_line = ""
    try:
        ltm = _LTM_REF.get("ltm")
        if ltm:
            q = stm.current_objective + " " + stm.goal
            facts = ltm.related_knowledge(q)
            if facts:
                know_line = "\n【関連知識（記憶グラフ）】" + " ／ ".join(facts)
            # ペンテスト攻撃状態を注入（状態追跡で次手を賢くする＝コンテキスト喪失対策）
            try:
                import modes as _modes
                if _modes.get_mode() in ("pentest", "recon"):
                    import pentest_kg
                    kg_line = pentest_kg.summary_for_planner(ltm)
                    if kg_line:
                        know_line += kg_line
            except Exception:
                pass
            # 過去の教訓を注入（使うほど賢くなる核心）
            lessons = ltm.relevant_lessons(q)
            if lessons:
                lesson_line = "\n【過去の教訓】" + " ／ ".join(
                    f"{l['lesson']}" for l in lessons)
            # 意味的に近い過去の記憶
            sims = ltm.semantic_search(q, limit=3)
            if sims:
                sem_line = "\n【類似した過去の経験】" + " ／ ".join(
                    f"{s['goal']}: {s['summary'][:40]}" for s in sims)
            # 再利用できる既存スキル（昇格段階を考慮して提示＝賢くなる核心）
            skills = ltm.relevant_skills(q)
            if skills:
                # 提示したスキルIDを記録（目的完了時に成否をmark_skill_used）
                for s in skills:
                    if s.get("id"):
                        _USED_SKILLS["ids"].add(s["id"])
                try:
                    import skill_system
                    sem_line += skill_system.format_for_planner(skills)
                except Exception:
                    sk = []
                    for s in skills:
                        sk.append(f"「{s['name']}」: {' → '.join(s['steps'])}")
                    sem_line += "\n【再利用できるスキル】" + " ／ ".join(sk)
    except Exception:
        pass
    # 使えるツール一覧を提示（type:"tool" で呼べる）
    tools_line = ""
    try:
        import tools.registry as _tr
        tools_line = "\n【使えるツール（type:\"tool\", name, args で呼ぶ）】\n" + _tr.specs_text()
    except Exception:
        pass
    kali_line = ""
    try:
        if ssh_session.is_connected():
            kali_line = kali_tools.prompt_text()
    except Exception:
        pass
    steps_line = ""
    if _STEPS.get("plan"):
        steps_line = "\n【今回の手順プラン】" + " → ".join(_STEPS["plan"]) + \
                     "（この流れに沿って1手ずつ進める）"
    # 攻撃対象インベントリと自動導出した攻撃経路を注入（点でなく繋がりで判断させる）
    engage_line = ""
    try:
        import engagement
        with engagement.Engagement() as _eg:
            txt = _eg.prompt_text()
        if txt:
            engage_line = "\n" + txt
    except Exception:
        pass
    context = f"【実行環境】{env_line}（この環境で動くコマンドを出すこと）" \
              f"{inst_line}{know_line}{lesson_line}{sem_line}{steps_line}{tools_line}{kali_line}{engage_line}\n\n" \
              + stm.build_context(related)
    if feedback:                       # 重複時など、前段の指摘を文脈に添えて出し直させる
        context += f"\n\n【注意】{feedback}"
    return ask_role(modes.system_prompt_role(), "plan", context, jc.handle_task,
                    task_text=stm.current_objective + " " + stm.goal)


def execute_action(action: dict) -> str:
    _emit(type="fn", fn="execute_action", note="executor: 行動を実行(承認/dry)")
    approver = _HOOK["approver"]
    if approver is None:
        # 承認関数が無い場合のフォールバック。
        # dry_run時は実際には実行しないので自動承認でよい。
        # 端末input(_ask_approval)はWeb/スレッド環境で固まるため使わない。
        approver = executor.auto_yes if _HOOK["dry"] else executor._ask_approval
    return executor.run_action(
        action,
        approver=approver,
        dry_run=_HOOK["dry"],
    )


def _objective_facts(stm: ShortTermMemory) -> str:
    """judge前の客観チェック。作成したはずのファイルが実在するか等を事実として添える。"""
    import os as _os
    facts = []
    ws = executor.WORKSPACE
    for r in stm.records:
        act = r.action if isinstance(r.action, dict) else {}
        # file書き込み / code保存 で path があれば実在確認
        path = act.get("path")
        if path and act.get("type") in ("file", "code"):
            full = _os.path.join(ws, path) if not _os.path.isabs(path) else path
            exists = _os.path.exists(full)
            facts.append(f"ファイル {path}: {'実在する' if exists else '存在しない'}")
    if not facts:
        return ""
    return "\n\n【客観的事実（システム確認済み）】\n" + "\n".join(facts)


def is_objective_done(stm: ShortTermMemory) -> bool:
    """judge役LLMに、これまでの行動と結果から目的達成を判定させる。
    事前にファイル実在などの客観的事実を確認して judge に渡す（嘘の完了を防ぐ）。"""
    _emit(type="fn", fn="is_objective_done", note="judge役: 目的の達成を判定")
    history = "\n".join(f"{r.action} → 結果: {r.result}" for r in stm.records)
    facts = _objective_facts(stm)
    try:
        data = ask_role("judge", "judge",
                        f"目的: {stm.current_objective}\n\nこれまでの行動と結果:\n{history}{facts}",
                        jc.handle_judge)
        _emit(type="judge", done=data["done"], reason=data.get("reason", ""))
        return bool(data["done"])
    except Exception as ex:                       # 判定不能なら未完了扱い（ループ継続）
        _emit(type="judge", done=False, reason=f"判定失敗: {ex}")
        return False


DEBATE_ROUNDS = 2     # planner↔critic の最大往復回数


def plan_with_debate(stm: ShortTermMemory, related: list, feedback: str) -> dict:
    """plannerが1手を提案し、criticが批評、合意するまで往復して最終案を返す。
    多エージェント協調。dry_run時はcriticを省いて速度優先。"""
    action = plan_next_action(stm, related, feedback)
    if _HOOK.get("dry"):
        return action
    import json as _j
    # criticに渡す「実行履歴」と「失敗済み行動」（誤りや再実行を検出させる）
    history = "\n".join(f"{i}. {r.action} → {r.result}"
                        for i, r in enumerate(stm.records, 1)) or "（まだ無し）"
    failed = [str(r.action) for r in stm.records if is_failure_result(r.result)]
    failed_txt = ("\n失敗・無効だった行動（これらの再実行は却下せよ）:\n"
                  + "\n".join(f"- {a}" for a in failed[-6:])) if failed else ""
    for rnd in range(DEBATE_ROUNDS):
        try:
            critique = ask_role("critic", "judge",
                f"目的: {stm.current_objective}\n"
                f"これまでの実行履歴:\n{history}{failed_txt}\n\n"
                f"plannerの提案: {_j.dumps(action, ensure_ascii=False)}\n"
                "この提案が、失敗済みの手の再実行や、直前の結果を無視していないか確認せよ。",
                jc.handle_critic)
        except Exception:
            break
        if critique.get("ok"):
            if rnd > 0:
                _emit(type="debate", round=rnd + 1, agreed=True,
                      advice=critique.get("advice", ""))
            return action            # criticが承認 → 合意
        advice = critique.get("advice", "別の手を検討")
        _emit(type="debate", round=rnd + 1, agreed=False, advice=advice,
              action=action)
        # plannerがcriticの指摘を踏まえて出し直す（失敗履歴も明示して別の手を強制）
        revise_fb = (f"critic指摘: {advice}\n"
                     f"前回の提案 {_j.dumps(action, ensure_ascii=False)} は却下された。"
                     f"{failed_txt}\n"
                     "必ず上記と異なる、結果を踏まえた別の手をJSONで出すこと。")
        revised = plan_next_action(stm, related, revise_fb)
        if revised == action:
            # 変わらないなら、もう一段強く別案を要求
            revised = plan_next_action(
                stm, related,
                revise_fb + "\n同じ手は絶対に却下される。手段そのものを変えること。")
            if revised == action:
                return action       # それでも変わらなければ打ち切り（ループ側が処理）
        action = revised
    return action                   # 合意できなくても最終案で進む


def plan_steps(stm: ShortTermMemory, ltm) -> list:
    """目的を複数の手順に分解する（多段階プランニング）。失敗時は空。"""
    _emit(type="fn", fn="plan_steps", note="steps役: 目的を手順に分解")
    try:
        lessons = ltm.relevant_lessons(stm.current_objective + " " + stm.goal)
        hint = ("\n参考になる過去の教訓: " + " ／ ".join(l["lesson"] for l in lessons)) if lessons else ""
        data = ask_role("steps", "plan",
                        f"目的: {stm.current_objective}{hint}", jc.handle_steps)
        return data.get("steps", [])[:6]
    except Exception:
        return []


def generate_skill(stm: ShortTermMemory, ltm) -> None:
    """成功した手順を汎用スキルとして蒸留・保存（Skill Generator）。"""
    _emit(type="fn", fn="generate_skill", note="skill役: 成功手順をスキル化")
    history = "\n".join(f"{r.action} → {r.result}" for r in stm.records)
    try:
        data = ask_role("skill", "judge",
                        f"達成した目的: {stm.current_objective}\n\n行動履歴:\n{history}",
                        jc.handle_skill)
        steps = data.get("steps", [])
        if steps and len(steps) >= 2:
            ltm.add_skill(data.get("name", stm.current_objective[:30]),
                          data.get("description", ""), steps,
                          data.get("tags", stm.tags))
            _emit(type="skill_learned", name=data.get("name", ""),
                  steps=steps)
    except Exception as ex:
        _emit(type="skill_learned", name="", steps=[], error=str(ex))


def reflect_and_learn(stm: ShortTermMemory, ltm, done: bool) -> None:
    """目的完了後に自己評価し、次回に活かす教訓を抽出して記憶する。"""
    _emit(type="fn", fn="reflect_and_learn", note="reflect役: 自己評価して教訓を学習")
    history = "\n".join(f"{r.action} → {r.result}" for r in stm.records)
    try:
        data = ask_role("reflect", "judge",
                        f"目的: {stm.current_objective}（達成={done}）\n\n行動履歴:\n{history}",
                        jc.handle_reflect)
        score = data.get("score", 0)
        for lesson in data.get("lessons", [])[:3]:
            if lesson and len(lesson) >= 2:
                ltm.add_lesson(stm.goal, lesson, score)
        _emit(type="reflect", score=score, lessons=data.get("lessons", []))
        # この目的で提示されたスキルに成否を記録（成功率→昇格判定に使う）
        try:
            for sid in list(_USED_SKILLS["ids"]):
                ltm.mark_skill_used(sid, success=bool(done))
        except Exception:
            pass
        _USED_SKILLS["ids"] = set()   # 次の目的へ向けてリセット
        # 成功かつ高評価なら、手順をスキルとして蒸留・保存（Skill Generator）
        if done and score >= 60:
            generate_skill(stm, ltm)
    except Exception as ex:
        _emit(type="reflect", score=0, lessons=[], error=str(ex))
        _USED_SKILLS["ids"] = set()


def summarize_objective(stm: ShortTermMemory) -> str:
    _emit(type="fn", fn="summarize_objective", note="assistant役: 成果を要約")
    history = "\n".join(f"{r.action} → 結果: {r.result}" for r in stm.records)
    data = ask_role("assistant", "summary",
                    f"次は目的「{stm.current_objective}」の行動と結果です。要約してください。\n{history}",
                    jc.handle_assistant)
    return data["conclusion"] if data["type"] == "summary" \
        else f"要約できず（{data['type']}）"


def short_term_snapshot() -> dict:
    """現在の短期記憶（作業中のゴール/目的/直近の行動）のスナップショット。"""
    stm = _STM_REF.get("stm")
    if not stm:
        return {"active": False}
    return {
        "active": True, "goal": stm.goal, "objectives": stm.objectives,
        "current_index": getattr(stm, "index", 0),
        "current_objective": stm.current_objective if stm.objectives else "",
        "steps": _STEPS.get("plan", []),
        "records": [{"action": r.action, "result": str(r.result)[:200]}
                    for r in stm.records],
    }


def run_agent(request: str, emit=None, approver=None, dry_run: bool = False) -> None:
    _HOOK.update(emit=emit, approver=approver, dry=dry_run)
    _STEPS["plan"] = []          # 前回タスクの手順プランをクリア（残留防止）
    _STM_REF["stm"] = None       # 前回タスクの短期記憶参照をクリア
    _reset_interventions()       # 介入キュー/停止フラグを初期化（前回の残り持ち越し防止）
    kali_tools.maybe_refresh()   # SSH接続中なら1日1回 apt list を更新
    try:
        import providers.registry as _reg
        if stats.observe not in _reg._OBSERVERS:
            _reg.add_observer(stats.observe)   # LLM呼び出しの成否/速度を記録
        if budget._on_event not in _reg._OBSERVERS:
            _reg.add_observer(budget._on_event)   # トークン消費を積算
    except Exception:
        pass
    stm, ltm = ShortTermMemory(max_records=5), LongTermMemory()
    _LTM_REF["ltm"] = ltm
    final_results = []
    _emit(type="goal_start", request=request)

    prev = session.load() if session.is_continue(request) else None
    if prev and prev.get("objectives"):
        # 前回セッションを復元（完了済みでも続行可能）
        objs = list(prev["objectives"])
        idx = min(prev.get("index", 0), len(objs))
        final_results = [tuple(r) for r in prev.get("results", [])]
        completed = idx >= len(objs)
        if completed:
            # 全完了済み → ユーザーの追加要望を新しい目的として足してから続行
            extra = _additional_objectives(request, prev["goal"], prev["tags"])
            if extra:
                objs += extra        # 残タスクとして追加（idxは据え置き＝追加分から実行）
            else:
                # 追加目的が作れない場合は、要望を1目的として直接追加
                objs.append(request)
        stm.set_goal({"goal": prev["goal"], "objectives": objs,
                      "tags": prev["tags"]})
        stm.index = idx
        _emit(type="resumed", goal=stm.goal, index=stm.index,
              objectives=stm.objectives, done_count=len(final_results),
              appended=(completed))
    else:
        goal = make_goal(request)
        stm.set_goal(goal)
    _emit(type="goal_done", goal=stm.goal, objectives=stm.objectives, tags=stm.tags)

    while not stm.finished:
      try:
        related = ltm.as_context_lines(stm.tags)
        _emit(type="objective_start", index=stm.index + 1, total=len(stm.objectives),
              objective=stm.current_objective, related=related)

        _STEPS["plan"] = plan_steps(stm, ltm)   # 多段階プラン: 目的を手順に分解
        if _STEPS["plan"]:
            _emit(type="step_plan", steps=_STEPS["plan"],
                  objective=stm.current_objective)

        done = False
        dedup = Deduplicator(history_size=5, loop_threshold=3)
        feedback = ""
        turn = 0
        dup_streak = 0          # 重複が連続した回数（別の手が出せていないサイン）
        fail_streak = 0         # 失敗が連続した回数（戦略変更の判断用）
        # 目的が完了するまでループ（暴走防止に上限あり。達したら打ち切る）
        while turn < MAX_TURNS_PER_OBJECTIVE:
            # 停止要求があれば安全な区切りで終了
            if _should_stop():
                _emit(type="intervention", kind="stop",
                      message="ユーザーの要求で実行を停止しました")
                stm.finished = True
                done = is_objective_done(stm) if turn else False
                break
            # ユーザーからの介入メッセージを取り込み、次のプランへ指示として注入
            intervention = _drain_interventions()
            if intervention:
                feedback = (f"【ユーザーからの指示】{intervention} "
                            "この指示を最優先で次の手に反映すること。"
                            + (f" 直前の状況: {feedback}" if feedback else ""))
                _emit(type="intervention", kind="steer", message=intervention)
            # plannerとcriticが討論して合意した1手を得る（多エージェント協調）
            action = plan_with_debate(stm, related, feedback)
            feedback = ""

            # ループ検知: 直近5手で同じ行動が3回以上 → 打ち切って次へ（無限ループ防止）
            if dedup.is_looping(action):
                _emit(type="loop_detected", action=action,
                      message="LOOP DETECTED: 同じ行動が繰り返されたため、この目的を打ち切ります")
                stm.add_record(action, "LOOP DETECTED（同一行動の反復のため打ち切り）")
                break

            if dedup.is_duplicate(action):
                dup_streak += 1
                dedup.note_attempt(action)    # 重複も履歴に刻む（ループ検知のため）
                feedback = explain_duplicate(action)
                _emit(type="duplicate", action=action, message=feedback)
                stm.add_record(action, "（重複のため未実行：別の手を促した）")
                if dup_streak >= 3:           # 重複ばかりで別の手が出ない → 打ち切り
                    _emit(type="loop_detected", action=action,
                          message="LOOP DETECTED: 重複提案が続いたため打ち切ります")
                    break
                continue   # 重複は手数に数えず、別の手を促す

            dup_streak = 0

            turn += 1
            _emit(type="action", turn=turn, action=action)
            dedup.remember(action)
            try:
                result = execute_action(action)
            except Exception as ex:        # 実行時エラーで止めず、原因をLLMへ渡して次の手で回復させる
                result = f"エラー: {ex}"
                feedback = (f"前の手でエラーが出たよ（{ex}）。"
                            "原因を踏まえて、別のやり方で次の手をJSONで出してね。")
                _emit(type="action_error", error=str(ex), action=action)
            _emit(type="exec_result", result=result)
            stm.add_record(action, result)
            # 成功時、攻撃チェーンを知識グラフに記録（状態追跡＝次手の精度向上）
            if not is_failure_result(result):
                try:
                    import modes as _modes
                    if _modes.get_mode() in ("pentest", "recon"):
                        import pentest_kg, re as _re
                        ltm_k = _LTM_REF.get("ltm")
                        if ltm_k and isinstance(action, dict):
                            # URLを文字列の途中からでも正しく抽出（host:port部分のみ）
                            blob = str(action.get("url") or "") + " " + \
                                str(action.get("command") or "")
                            murl = _re.search(r"https?://([^/\s\"']+)", blob)
                            host = murl.group(1) if murl else ""
                            # 成果（フラグ/認証情報）を結果から抽出
                            loot = ""
                            mflag = _re.search(r"FLAG\{[^}]+\}", str(result))
                            if mflag:
                                loot = mflag.group(0)
                            else:
                                # 既知のフラグ的トークン（英数_を含む値）を拾う。
                                # 「password: xxx」のラベルでなく値側を取る。
                                mc = _re.search(
                                    r"(?:pw|pass\w*|cred\w*|token)[\s:=]+([^\s\"']{4,})",
                                    str(result), _re.I)
                                if mc:
                                    loot = mc.group(1)
                            if host and loot:
                                pentest_kg.record_chain(
                                    ltm_k, host, "http",
                                    stm.current_objective[:30],
                                    str(action.get("type", "action")), loot)
                except Exception:
                    pass
            # 結果がエラー文字列なら「戦略変更」を促す（同じ手の繰り返しを防ぐ）
            if not feedback and is_failure_result(result):
                fail_streak += 1
                # 構造化された再計画指令を生成（型付きの方針転換）
                attempted = ""
                if isinstance(action, dict):
                    attempted = (action.get("command") or action.get("url")
                                 or action.get("name") or "")
                try:
                    import replan as _rp
                    directive = _rp.analyze(result, stm.current_objective, attempted)
                    feedback = (f"前の手は失敗した（{result[:80]}）。{directive['replan_hint']}"
                                " 同じ手は繰り返さないこと。")
                    # 失敗教訓をその場でLTMへ（次の同種objに即反映＝セッション内学習）
                    ltm = _LTM_REF.get("ltm")
                    if ltm:
                        _rp.record_immediate_lesson(ltm, stm.current_objective,
                                                    attempted, result, stm.goal)
                except Exception:
                    hint = "別のコマンド/手段に切り替えて" if fail_streak >= 2 else "原因を直して"
                    feedback = (f"前の手は失敗した（{result[:80]}）。{hint}次の手を出して。"
                                "同じ手は繰り返さないこと。")
                _emit(type="retry_strategy", fail_streak=fail_streak, result=result[:120])
                if fail_streak >= 3:       # 失敗が続く → 戦略を立て直す（動的再計画）
                    # ペンテスト系モードでは攻撃グラフから別の有望な枝を探す（ReAct）
                    branched = False
                    try:
                        if modes.get_mode() in ("pentest", "recon"):
                            import strategist
                            best = strategist.pick_best(stm.current_objective, n=3)
                            if best:
                                _STEPS["plan"] = [best.get("first_action", "")]
                                _emit(type="replan",
                                      steps=[f"[{best['phase']}] {best['hypothesis']}"],
                                      objective=stm.current_objective)
                                branched = True
                    except Exception:
                        pass
                    if not branched:
                        new_steps = plan_steps(stm, ltm)
                        if new_steps:
                            _STEPS["plan"] = new_steps
                            _emit(type="replan", steps=new_steps,
                                  objective=stm.current_objective)
                    fail_streak = 0
            else:
                fail_streak = 0
            if feedback:                   # エラー回復のフィードバックがあれば判定せず次ターンへ
                continue
            if is_objective_done(stm):     # judge役が「達成」と言うまで続ける
                done = True
                break
        if not done:
            _emit(type="objective_giveup", objective=stm.current_objective,
                  turns=turn)

        summary = summarize_objective(stm)
        ltm.save(goal=stm.goal, objective=stm.current_objective,
                 summary=summary, tags=stm.tags, success=done)
        _emit(type="memory_save", summary=summary, success=done,
              objective=stm.current_objective)
        reflect_and_learn(stm, ltm, done)   # 自己評価して教訓を記憶（使うほど賢くなる）
        final_results.append((stm.current_objective, summary, done))
        stm.advance()
        session.save(stm.goal, stm.objectives, stm.index, stm.tags,
                     [list(r) for r in final_results])   # 続行用に進捗を保存
      except Exception as ex:        # 目的単位の想定外エラーでも全体は止めない
        _emit(type="objective_error", objective=stm.current_objective, error=str(ex))
        final_results.append((stm.current_objective, f"エラーで中断: {ex}", False))
        _USED_SKILLS["ids"] = set()   # スキルIDが次の目的へリークしないよう確実にリセット
        stm.advance()

    # ===== 最終結果のまとめ表示 =====
    ok = sum(1 for _, _, d in final_results if d)
    _emit(type="final_report", goal=stm.goal, total=len(final_results),
          done=ok, results=[
              {"objective": o, "summary": su, "success": d}
              for (o, su, d) in final_results
          ])
    # 記憶整理：重複削除に加え、教訓→スキル蒸留と剪定まで行う（使うほど濃縮）
    try:
        import consolidation
        cons = consolidation.run_full(ltm)
        if any(cons.get(k) for k in ("removed_duplicates", "removed_lessons",
                                     "promoted", "pruned_lessons", "pruned_skills")):
            _emit(type="consolidated", **{k: v for k, v in cons.items()
                                          if k != "rubrics"})
    except Exception:
        try:
            cons = ltm.consolidate()
            if cons.get("removed_duplicates") or cons.get("removed_lessons"):
                _emit(type="consolidated", **cons)
        except Exception:
            pass
    inst = installs.load()
    if inst:
        _emit(type="installs", items=inst)
    # 実runのテレメトリを能力ベクトルへ観測（弱め重み。AgentBench採点を流用）
    try:
        import capabilities
        import agentbench
        import providers.registry as _reg
        # plan役の現モデルを「このrunを主導したモデル」とみなす
        route = _reg.ROLE_ROUTES.get("plan", [])
        if route:
            prov, mdl = route[0][0], route[0][1]
            key = f"{prov}/{mdl}"
            # run内の行動軌跡を簡易ステップ化してルーブリック採点
            steps = []
            for o, su, d in final_results:
                steps.append({"ev": "exec_result", "result": su,
                              "conclusion": ("達成" if d else "未達")})
            ok_rate = (sum(1 for _, _, d in final_results if d)
                       / len(final_results)) if final_results else 0
            rubric = agentbench.score_trajectory(steps, ok_rate >= 0.5)
            capabilities.observe_from_run(key, {
                "planning": rubric["planning"],
                "reflection": rubric["reflection"],
                "tool_usage": rubric["tool_usage"],
                "security": rubric["security"],
            })
    except Exception:
        pass
    _emit(type="run_done", ltm_count=ltm.count())
    _LTM_REF["ltm"] = None
    ltm.close()


if __name__ == "__main__":
    if "--installs" in sys.argv:        # インストール履歴だけ表示して終了
        print(installs.summary())
        sys.exit(0)
    req = " ".join(sys.argv[1:]) or "プロジェクト直下のPythonファイル一覧を調べてメモにまとめたい"
    run_agent(req)
