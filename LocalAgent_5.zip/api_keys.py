# -*- coding: utf-8 -*-
#api_keys.py — 各プロバイダが使うAPIキーの「環境変数名」を一元管理（UIから変更可）
"""
プロバイダごとに、どの環境変数名のキーを使うかを保持する。
複数キー（GROQ_API_KEY1 / GROQ_API_KEY2 など）がある場合、UIから選択できる。
既定値は各プロバイダの従来のキー名。設定は api_keys.json に永続化。
"""
from __future__ import annotations

import json
import os

_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "api_keys.json")

# プロバイダ → 既定のキー環境変数名
_DEFAULTS = {
    "groq": "GROQ_API_KEY1",
    "cerebras": "CREBRAS_API_KEY",
    "google_studio": "GOOGLE_API_KEY2",
    "open_router": "OPEN_ROUTER_API_KEY",
    "mistral": "MISTRAL_API_KEY",
}

# プロバイダ → キー名を探すときのマッチ語（.envから候補を見つける）
_MATCH = {
    "groq": ("GROQ",),
    "cerebras": ("CEREBRAS", "CREBRAS"),
    "google_studio": ("GOOGLE", "GEMINI"),
    "open_router": ("OPENROUTER", "OPEN_ROUTER"),
    "mistral": ("MISTRAL",),
}

_state = {"names": dict(_DEFAULTS)}


def _load():
    try:
        with open(_FILE, encoding="utf-8") as f:
            saved = json.load(f)
        for p, name in saved.items():
            if p in _state["names"] and name:
                _state["names"][p] = name
    except Exception:
        pass


def _save():
    try:
        with open(_FILE, "w", encoding="utf-8") as f:
            json.dump(_state["names"], f, ensure_ascii=False, indent=2)
    except Exception:
        pass


_load()


def key_name(provider: str) -> str:
    """そのプロバイダが現在使うキーの環境変数名。"""
    return _state["names"].get(provider, _DEFAULTS.get(provider, ""))


def set_key_name(provider: str, name: str) -> None:
    if provider in _DEFAULTS and name:
        _state["names"][provider] = name
        _save()


def get_key(provider: str):
    """そのプロバイダのAPIキー値を環境変数から取得（dotenv経由）。"""
    from get_env import env_controler as env
    return env.get_env(key_name(provider))


def available_keys(provider: str) -> list[str]:
    """.env/環境変数から、そのプロバイダ向けらしいキー名の候補を列挙。"""
    match = _MATCH.get(provider, ())
    found = sorted(k for k in os.environ
                   if "KEY" in k.upper() and any(m in k.upper() for m in match))
    cur = key_name(provider)
    if cur and cur not in found:
        found.insert(0, cur)
    return found


def all_config() -> dict:
    """UI表示用：プロバイダごとの現在のキー名と候補一覧。"""
    out = {}
    for p in _DEFAULTS:
        out[p] = {"current": key_name(p), "default": _DEFAULTS[p],
                  "available": available_keys(p)}
    return out
