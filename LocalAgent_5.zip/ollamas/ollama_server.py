# -*- coding: utf-8 -*-
#ollama_server.py

import requests
import subprocess
import time

def is_ollama_running():
    try:
        r = requests.get("http://localhost:11434")
        return r.status_code == 200
    except requests.exceptions.ConnectionError:
        return False

def start_ollama():
    print("Ollamaを起動中...")

    # OS依存なしで基本起動
    subprocess.Popen(
        ["ollama", "serve"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )

    # 起動待ち
    for i in range(10):
        time.sleep(1)
        if is_ollama_running():
            print("Ollama起動OK")
            return True

    raise RuntimeError("Ollamaの起動に失敗しました")

def ensure_ollama():
    if is_ollama_running():
        print("Ollamaはすでに起動しています")
        return True

    return start_ollama()