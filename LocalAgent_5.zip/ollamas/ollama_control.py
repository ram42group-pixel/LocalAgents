# -*- coding: utf-8 -*-
from dataclasses import dataclass
from datetime import datetime

import ollama

ROLES = ("user", "system", "assistant")


@dataclass
class Response:
    model: str
    created_at: datetime
    role: str
    content: str
    done: bool

    def __str__(self) -> str:
        return self.content

    @classmethod
    def from_ollama(cls, data: dict):
        return cls(
            model=data["model"],
            created_at=datetime.fromisoformat(
                data["created_at"].replace("Z", "+00:00")
            ),
            role=data["message"]["role"],
            content=data["message"]["content"],
            done=data["done"]
        )


def send(text: str, model: str, role: str = "user") -> Response:
    if not text or not model:
        raise ValueError("text or model が空です")

    if role not in ROLES:
        raise ValueError(
            f"roleは {', '.join(ROLES)} のいずれかである必要があります"
        )

    res = ollama.chat(
        model=model,
        messages=[
            {
                "role": role,
                "content": text
            }
        ]
    )

    return Response.from_ollama(res)


def send_messages(messages: list[dict], model: str) -> Response:
    """
    会話履歴（messagesリスト）ごと送る。send() の複数メッセージ版。
    system + user の2枚送りや、短期記憶を含むコンテキストを渡すときはこちら。
    例: [{"role": "system", "content": "..."}, {"role": "user", "content": "..."}]
    """
    if not messages or not model:
        raise ValueError("messages or model が空です")

    for m in messages:
        if m.get("role") not in ROLES:
            raise ValueError(
                f"roleは {', '.join(ROLES)} のいずれかである必要があります"
            )
        if not m.get("content"):
            raise ValueError("contentが空のメッセージがあります")

    res = ollama.chat(model=model, messages=messages)
    return Response.from_ollama(res)


def get_models() -> list[str]:
    return [model.model for model in ollama.list().models]


if __name__ == "__main__":
    models = get_models()

    response = send(
        text="Pythonについて一言で説明して",
        model=models[0]
    )

    print("モデル :", response.model)
    print("日時   :", response.created_at)
    print("ロール :", response.role)
    print("完了   :", response.done)
    print("本文   :", response.content)