# -*- coding: utf-8 -*-
#memory/embed.py — テキストをベクトル化する（ollama優先、無ければ簡易ベクトル）
"""
ollama の埋め込みモデル(nomic-embed-text等)があればそれを使い、
無ければ文字n-gramのハッシュで簡易ベクトルを作る（依存ゼロのフォールバック）。
どちらも cosine 類似度で比較できる固定長ベクトルを返す。
"""
from __future__ import annotations

import hashlib
import math
import re

EMBED_MODEL = "nomic-embed-text"
_DIM = 256          # 簡易ベクトルの次元
_backend = {"mode": None}   # "ollama" / "hash"（初回に判定）


def _detect_backend() -> str:
    if _backend["mode"]:
        return _backend["mode"]
    try:
        import ollama
        ollama.embeddings(model=EMBED_MODEL, prompt="test")
        _backend["mode"] = "ollama"
    except Exception:
        _backend["mode"] = "hash"
    return _backend["mode"]


def _hash_vector(text: str) -> list[float]:
    """文字2-gramをハッシュして次元に割り当てる簡易埋め込み。"""
    vec = [0.0] * _DIM
    text = re.sub(r"\s+", "", (text or "").lower())
    grams = [text[i:i + 2] for i in range(max(len(text) - 1, 1))] or [text]
    for g in grams:
        h = int(hashlib.md5(g.encode()).hexdigest(), 16)
        vec[h % _DIM] += 1.0
    n = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [v / n for v in vec]


def embed(text: str) -> list[float]:
    if _detect_backend() == "ollama":
        try:
            import ollama
            r = ollama.embeddings(model=EMBED_MODEL, prompt=text or "")
            return r["embedding"]
        except Exception:
            _backend["mode"] = "hash"
    return _hash_vector(text)


def cosine(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a)) or 1.0
    nb = math.sqrt(sum(y * y for y in b)) or 1.0
    return dot / (na * nb)


def backend_name() -> str:
    return _detect_backend()
